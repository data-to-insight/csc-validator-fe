import pandas as pd
from cin_validator.cin_validator_class import create_user_report

df = pd.DataFrame([
    {"tables_affected": "Header", "columns_affected"},
    ])

