# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['cin_validator',
 'cin_validator.rule_engine',
 'cin_validator.rules',
 'cin_validator.rules.cin2022_23',
 'cin_validator.test_engine']

package_data = \
{'': ['*']}

modules = \
['rpc_main']
install_requires = \
['numpy==1.22.4', 'pandas==1.4.2']

setup_kwargs = {
    'name': 'cin-validator',
    'version': '0.1.0',
    'description': '',
    'long_description': 'None',
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'py_modules': modules,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
